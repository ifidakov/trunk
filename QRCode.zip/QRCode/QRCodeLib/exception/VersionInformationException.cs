using System;
namespace ThoughtWorks.QRCode.ExceptionHandler
{
	[Serializable]
	public class VersionInformationException:System.ArgumentException
	{
	}
}